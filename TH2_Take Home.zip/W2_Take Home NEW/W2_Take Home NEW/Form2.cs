﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W2_Take_Home_NEW
{
    public partial class Form2 : Form
    {
        string[] keyboardList = new string[1];
        string[] hurufdiKata = new string[5];
        List<bool> benarWin = new List<bool>();//ini klo dihapus jdi ungu" public partial class form2 nyaaa idk
      
        public Form2()
        {
            InitializeComponent();
            lb_KataAcak.Text = Form1.HasilKataAcak;

            hurufdiKata[0] = lb_KataAcak.Text.Substring(0, 1).ToUpper();
            hurufdiKata[1] = lb_KataAcak.Text.Substring(1, 1).ToUpper();
            hurufdiKata[2] = lb_KataAcak.Text.Substring(2, 1).ToUpper();
            hurufdiKata[3] = lb_KataAcak.Text.Substring(3, 1).ToUpper();
            hurufdiKata[4] = lb_KataAcak.Text.Substring(4, 1).ToUpper();
        }

        public void pecahanhuruf()
        {
            for (int i = 0; i < 5; i++)
            {
                if (keyboardList[0] == hurufdiKata[i])
                {
                    if (i == 0 && lb_Huruf1.Text == "_____")
                    {
                        lb_Huruf1.Text = keyboardList[0];
                        benarWin.Add(true);
                    }
                    if (i == 1 && lb_Huruf2.Text == "_____")
                    {
                        lb_Huruf2.Text = keyboardList[0];
                        benarWin.Add(true);
                    }
                    if (i == 2 && lb_Huruf3.Text == "_____")
                    {
                        lb_Huruf3.Text = keyboardList[0];
                        benarWin.Add(true);
                    }
                    if (i == 3 && lb_Huruf4.Text == "_____")
                    {
                        lb_Huruf4.Text = keyboardList[0];
                        benarWin.Add(true);
                    }
                    if (i == 4 && lb_Huruf5.Text == "_____")
                    {
                        lb_Huruf5.Text = keyboardList[0];
                        benarWin.Add(true);
                    }
                }
            }
            sudahbenarwin();
        }

        private void sudahbenarwin()
        {
            if (benarWin.Count() == 5)
            {
                MessageBox.Show("You Win");
            }
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_Q.Text;
            pecahanhuruf();
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_W.Text;
            pecahanhuruf();
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_E.Text;
            pecahanhuruf();
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_R.Text;
            pecahanhuruf();
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_T.Text;
            pecahanhuruf();
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_Y.Text;
            pecahanhuruf();
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_U.Text;
            pecahanhuruf();
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_I.Text;
            pecahanhuruf();
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_O.Text;
            pecahanhuruf();
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_P.Text;
            pecahanhuruf();
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_A.Text;
            pecahanhuruf();
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_S.Text;
            pecahanhuruf();
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_D.Text;
            pecahanhuruf();
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_F.Text;
            pecahanhuruf();
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_G.Text;
            pecahanhuruf();
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_H.Text;
            pecahanhuruf();
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_J.Text;
            pecahanhuruf();
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_K.Text;
            pecahanhuruf();
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_L.Text;
            pecahanhuruf();
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_Z.Text;
            pecahanhuruf();
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_X.Text;
            pecahanhuruf();
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_C.Text;
            pecahanhuruf();
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_V.Text;
            pecahanhuruf();
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_B.Text;
            pecahanhuruf();
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_N.Text;
            pecahanhuruf();
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            keyboardList[0] = btn_M.Text;
            pecahanhuruf();
        }
    }
}
