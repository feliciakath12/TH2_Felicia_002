﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W2_Take_Home_NEW
{
    public partial class Form1 : Form
    {
        public static string HasilKataAcak = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Play_Click(object sender, EventArgs e)
        {
            List<string> listkata = new List<string>();
            listkata.Add(tb_Word1.Text);
            listkata.Add(tb_Word2.Text);
            listkata.Add(tb_Word3.Text);
            listkata.Add(tb_Word4.Text);
            listkata.Add(tb_Word5.Text);
            

            bool cek = false;
            int total = 0;
            total = ((listkata[0].Length) + (listkata[1].Length) + (listkata[2].Length) + (listkata[3].Length) + (listkata[4].Length));


            for (int i = 0; i <= 4; i++)
            {
                int[] countcek = { 0, 1, 2, 3, 4 };
                countcek = countcek.Except(new int[] { i }).ToArray();
                for (int j = 0; j < 4; j++)
                {
                    if (listkata[i] == listkata[countcek[j]])
                    {
                        cek = true;
                    }
                }
            }

            if (total != 25)
            {
                MessageBox.Show("Eror, masukan 5 huruf");
            }
            if (cek == true)
            {
                MessageBox.Show("Eror, ada kata yang sama");
            }
            else if (cek == false && total == 25)
            {
                MessageBox.Show("Let's Play");

                Random rnd = new Random();
                int acak = rnd.Next(0, 4);

                for (int i = 0; i <= 4; i++)
                {
                    if (acak == i)
                    {
                        HasilKataAcak = listkata[i];
                    }
                }

                Form2 f2 = new Form2();
                f2.Show();
                this.Hide();
            }

        }
    }
}
